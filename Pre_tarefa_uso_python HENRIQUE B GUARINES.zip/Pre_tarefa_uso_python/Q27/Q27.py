"""27. Explique quais são as aplicações da biblioteca matplotlib."""

import asp

a = (
    """A biblioteca matplotlib é uma biblioteca de plotagem 2D em Python 
que produz figuras de qualidade em uma variedade de formatos e ambientes. 
Matplotlib pode ser usado para gerar gráficos, histogramas, espectros de potência, 
gráficos de barras, gráficos de erro, gráficos de dispersão, etc. 
Além disso, a biblioteca matplotlib é usada para criar gráficos interativos em Python.""")

rsp27 = [("27. \n", a)]
asp.gerar_arquivo_texto("Q27.txt", "RESPOSTAS USO PYTHON", rsp27)
