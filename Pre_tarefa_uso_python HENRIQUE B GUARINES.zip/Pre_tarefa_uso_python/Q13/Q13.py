"""13. Plote o gráfico das seguintes funções:"""
