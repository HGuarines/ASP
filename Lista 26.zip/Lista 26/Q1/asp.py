""" Lib de Henrique para ASP 1 """


import numpy as np


def gerar_arquivo_texto(nome_arquivo, titulo, calculos):
    """
    # Adiciona ou gera um arquivo de texto formatado com título, autor e cálculos fornecidos, evitando duplicações.

    **Parâmetros:**\n
    nome_arquivo (str): O nome do arquivo de saída.\n
    titulo (str): O título a ser exibido no arquivo.\n
    calculos (lista de tuplas): Uma lista onde cada tupla contém uma expressão e seu resultado.

    # Exemplo de uso:
    calculos = [
        ('a = 5 + 3', 5 + 3),
        ('b = 10 - 4', 10 - 4),
        ('c = 7 * 2', 7 * 2),
        ('d = 15 / 3', 15 / 3),
        ('e = 15 // 2', 15 // 2),
        ('g = 2 ** 3', 2 ** 3)
    ]

    gerar_arquivo_texto("exemplo.txt", "Funções Matemáticas Básicas", calculos)
    """
    import os

    linha = '\n' + 45 * '*' + '\n'
    conteudo_adicionar = []

    # Criar cabeçalho se for novo arquivo
    if not os.path.exists(nome_arquivo):
        conteudo_adicionar.append(linha)
        conteudo_adicionar.append(f'{" " * 10}{titulo}{" " * 10}\n')
        conteudo_adicionar.append(
            f'{" " * 10}Henrique B Guarines{" " * 20}\n')
        conteudo_adicionar.append(linha)
        conteudo_adicionar.append('\n')

    # Carregar conteúdo existente para evitar duplicações
    conteudo_existente = ""
    if os.path.exists(nome_arquivo):
        with open(nome_arquivo, 'r', encoding="utf-8") as f:
            conteudo_existente = f.read()

    # Construir as novas linhas de cálculo
    for expressao, resultado in calculos:
        linha_calculo = f'{expressao}{float(resultado) if isinstance(resultado, (int, float)) else resultado}\n'
        if linha_calculo not in conteudo_existente:
            conteudo_adicionar.append(linha_calculo)

    # Apenas escrever se houver conteúdo novo
    if conteudo_adicionar:
        with open(nome_arquivo, 'a', encoding="utf-8") as f:
            f.writelines(conteudo_adicionar)
            f.write(linha)


def ret2pol(cplx, unidade='r'):
    """
    # Converte um número complexo retangular para forma polar.

    **Parâmetros:**\n
    cplx (complex): O número complexo a ser convertido. (a + jb)
    unidade (str): A unidade do ângulo ('r' para radianos, 'g' para graus). Padrão é 'r'.

    **Retorno:**\n
    Uma tupla contendo o módulo e o argumento do número complexo fornecido. (r, phi)
    """
    from cmath import polar
    from numpy import degrees

    r, phi = polar(cplx)

    if unidade == 'g':
        phi = degrees(phi)  # Converter radianos para graus

    return r, phi


def pol2ret(r, phi, unidade='r'):
    """
    # Converte um número complexo polar para forma retangular.

    **Parâmetros:**\n
    r (float): O módulo do número complexo.\n
    phi (float): O argumento do número complexo.\n
    unidade (str): A unidade do ângulo ('r' para radianos, 'g' para graus). Padrão é 'r'.

    **Retorno:**\n
    O número complexo na forma retangular. (a + jb)
    """
    from cmath import rect
    from numpy import radians

    if unidade == 'g':
        phi = radians(phi)  # Converter graus para radianos

    return rect(r, phi)


def pot_comp1f(V, I):
    """
    # Calcula a potência complexa em um circuito monofásico.

    **Parâmetros:**\n
    V (a + jb): A tensão complexa no circuito.\n
    I (a + jb): A corrente complexa no circuito.

    **Retorno:**\n
    A potência complexa no circuito. (P + jQ)
    """
    S = V * I.conjugate()
    return S


def pot_comp3f(Va, Ia, Vb, Ib, Vc, Ic):
    """
    # Calcula a potência complexa trifásica S.

    **Parâmetros:**\n
    Va, Vb, Vc: Tensões de fase (números complexos)\n
    Ia, Ib, Ic: Correntes de fase (números complexos)

    **Retorno:**\n
    Potência complexa total S.
    """
    from numpy import conj
    Sa = Va * conj(Ia)
    Sb = Vb * conj(Ib)
    Sc = Vc * conj(Ic)

    S_total = Sa + Sb + Sc
    return S_total


def cor_carga(P, V, FP, N=3):
    """
    # Calcula a corrente de carga elétrica (I) em um sistema monofásico ou trifásico.

    **Parâmetros:**\n
    P (float): Potência ativa da carga em watts (W).\n
    V (float): Tensão de operação em volts (V).\n
    FP (float): Fator de potência (0 a 1).\n
    N (int, opcional): Número de fases (1 para monofásico, 3 para trifásico). Padrão = 3.

    **Retorno:**\n
    I (float): Corrente de carga em amperes (A).
    """
    P = float(abs(P))  # Garantir que seja um número real positivo
    V = float(abs(V))
    FP = float(FP)

    if N == 1:  # Monofásico
        I = P / (V * FP)
    elif N == 3:  # Trifásico
        from math import sqrt
        I = P / (sqrt(3) * V * FP)
    else:
        raise ValueError(
            "O número de fases deve ser 1 (monofásico) ou 3 (trifásico).")

    return I


def imp_serie(*impedancias):
    """
    # Calcula a impedância equivalente de múltiplos elementos em série.

    **Parâmetros:**\n
    *impedancias (a + jb): As impedâncias dos elementos.

    **Retorno:**\n
    A impedância equivalente dos elementos em série. (a + jb)
    """
    return sum(impedancias)


def imp_paral(*impedancias):
    """
    # Calcula a impedância equivalente de múltiplos elementos em paralelo.

    **Parâmetros:**\n
    *impedancias (a + jb): As impedâncias dos elementos.

    **Retorno:**\n
    A impedância equivalente dos elementos em paralelo. (a + jb)
    """
    from functools import reduce

    if len(impedancias) == 0:
        raise ValueError("Deve haver pelo menos uma impedância fornecida.")

    # Função auxiliar para calcular a impedância equivalente de dois elementos em paralelo
    def paralelo(Z1, Z2):
        return (Z1 * Z2) / (Z1 + Z2)

    # Reduzir a lista de impedâncias usando a função auxiliar
    return reduce(paralelo, impedancias)


def oper_comp(c1, form1, op, c2, form2):
    """
    # Realiza operações com números complexos.

    **Parâmetros:**\n
    c1 (complex): O primeiro número complexo.\n
    form1 (str): A forma do primeiro número complexo ("r: retangular" ou "p: polar, em radianos").\n
    op (str): O operador a ser aplicado ("+", "-", "*", "/").\n
    c2 (complex): O segundo número complexo.\n
    form2 (str): A forma do segundo número complexo ("r: retangular" ou "p: polar", em radianos).

    **Retorno:**\n
    O resultado da operação entre os números complexos fornecidos.
    """

    if form1 == "p":
        c1 = pol2ret(*c1)
    if form2 == "p":
        c2 = pol2ret(*c2)

    if op == "+":
        return c1 + c2
    elif op == "-":
        return c1 - c2
    elif op == "*":
        return c1 * c2
    elif op == "/":
        return c1 / c2
    elif op not in ["+", "-", "*", "/"]:
        raise ValueError("Operação inválida. Use '+', '-', '*' ou '/'.")
    elif form1 not in ["r", "p"] or form2 not in ["r", "p"]:
        raise ValueError("Forma inválida. Use 'r' ou 'p'.")


def Qcor_pot(P, FPA, FPN):
    """
    # Calcula a potência reativa de correção necessária para compensar o fator de potência de um sistema.

    **Parâmetros:**\n
    P (float): A potência ativa da carga em W.\n
    FPA (float): O fator de potência antigo do sistema (0 a 1).\n
    FPN (float): O fator de potência desejado para o sistema (0 a 1).

    **Retorno:**\n
    A potência reativa de correção necessária em VAr.
    """
    from math import tan, acos

    FPA = acos(FPA)
    FPN = acos(FPN)
    Qc = P * (tan(FPA) - tan(FPN))
    return Qc


def cte_gener(Zpi, Ya, Yb):
    """
    # Calcula os parâmetros ABCD para um quadripolo obtido a partir de uma rede PI.

    **Parâmetros:**\n
    Zpi (float ou complexo): Impedância em série na rede PI.\n
    Ya (float ou complexo): Admitância shunt na entrada.\n
    Yb (float ou complexo): Admitância shunt na saída.

    **Retorno:**\n
    Uma tupla contendo os parâmetros da matriz de transmissão (A, B, C, D).
    """
    A = 1 + Zpi * Ya
    B = Zpi
    C = Ya + Yb + Zpi * Ya * Yb
    D = 1 + Zpi * Yb

    return A, B, C, D


def format_complex(c, form='r', precisao=2):
    """
    # Formata um número complexo em uma string legível.

    **Parâmetros:**\n
    c (complex): O número complexo a ser formatado. **imput do angulo sempre em radianos**\n
    form (str): A forma do número complexo ('r' para retangular, 'p' para polar, 'e' para exponencial). Padrão é 'r'.\n
    precisao (int): O número de casas decimais para arredondamento. Padrão é 2.\n

    **Retorno:**\n
    Uma string representando o número complexo no formato "a + bj" ou "a - bj" para retangular,
    "r ∠ θ°" para polar, ou "r * e^(jθ)" para exponencial.
    """
    from math import degrees
    from cmath import polar

    if isinstance(c, tuple):  # Se já for uma tupla, não precisa chamar polar()
        r, theta = c
    elif isinstance(c, complex):  # Se for um número complexo, converta
        r, theta = polar(c)
    else:
        raise TypeError(
            "Entrada inválida: deve ser um número complexo ou uma tupla (módulo, fase).")

    if form == 'r':
        parte_real = f'{c.real:.{precisao}f}' if c.real != 0 else ''
        parte_imaginaria = f'{abs(c.imag):.{precisao}f}j' if c.imag != 0 else ''
        if c.imag > 0 and c.real != 0:
            parte_imaginaria = f'+ {parte_imaginaria}'
        elif c.imag < 0:
            parte_imaginaria = f'- {parte_imaginaria}'
        if parte_real and parte_imaginaria:
            return f'{parte_real} {parte_imaginaria}'
        elif parte_real:
            return parte_real
        elif parte_imaginaria:
            return parte_imaginaria
        else:
            return '0'
    elif form == 'p':
        theta = degrees(theta)  # Converter radianos para graus
        return f'{r:.{precisao}f} ∠ {theta:.{precisao}f}°'
    elif form == 'e':
        return f'{r:.{precisao}f}*e^{theta:.{precisao}f}j'
    else:
        raise ValueError(
            "Forma inválida. Use 'r' para retangular, 'p' para polar ou 'e' para exponencial.")


def quad_casc(A1, B1, C1, D1, A2, B2, C2, D2):
    """
    # Calcula os parâmetros ABCD de um quadripolo obtido pela cascata de dois quadripolos.

    **Parâmetros:**\n
    A1, B1, C1, D1: Parâmetros do primeiro quadripolo.\n
    A2, B2, C2, D2: Parâmetros do segundo quadripolo.

    **Retorno:**\n
    Uma tupla contendo os parâmetros da matriz de transmissão (A, B, C, D).
    """
    A = A1 * A2 + B1 * C2
    B = A1 * B2 + B1 * D2
    C = C1 * A2 + D1 * C2
    D = C1 * B2 + D1 * D2

    return A, B, C, D


def quad_par(A1, B1, C1, D1, A2, B2, C, D2):
    """
    # Calcula os parâmetros ABCD de um quadripolo obtido pela paralelo de dois quadripolos.

    **Parâmetros:**\n
    A1, B1, C1, D1: Parâmetros do primeiro quadripolo.\n
    A2, B2, C2, D2: Parâmetros do segundo quadripolo.

    **Retorno:**\n
    Uma tupla contendo os parâmetros da matriz de transmissão (A, B, C, D).
    """
    A = A1 + A2
    B = B1 + B2
    C = C1 + C2
    D = D1 + D2

    return A, B, C, D


def cirpi(V2, I2, Z, Ya, Yb, nomearq=None):
    """
    # Calcula a tensão V1 e a corrente I1 no terminal transmissor de um circuito Pi, conhecendo a tensão V2, corrente I2, impedância Z e admitâncias Ya e Yb.

    **Parâmetros:**\n
    V2 (complex): Tensão no terminal receptor\n
    I2 (complex): Corrente no terminal receptor\n
    Z (complex): Impedância em série\n
    Ya (complex): Admitância shunt na entrada\n
    Yb (complex): Admitância shunt na saída\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    (V1, I1) - Tensão e corrente no terminal transmissor
    """
    import numpy as np

    # Utilizando a função existente para calcular os parâmetros ABCD
    A, B, C, D = cte_gener(Z, Ya, Yb)

    # Resolvendo para V1 e I1 usando a equação matricial
    matriz_abcd = np.array([[A, B], [C, D]])
    vetor_v2_i2 = np.array([V2, I2])
    V1, I1 = np.dot(matriz_abcd, vetor_v2_i2)

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada:', ''),
            ("V2 = ", format_complex(V2)),
            ("I2 = ", format_complex(I2)),
            ("Z  = ", format_complex(Z)),
            ("Ya = ", format_complex(Ya)),
            ("Yb = ", format_complex(Yb)),
            ('\nResultados:', ''),
            ("V1 = ", format_complex(V1)),
            ("I1 = ", format_complex(I1))
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(nomearq, "Resultados do Circuito Pi", calculos)

    return V1, I1


def cirpir(V1, I1, Z, Ya, Yb, nomearq=None):
    """
    # Calcula a tensão V2 e a corrente I2 no terminal receptor de um circuito Pi, conhecendo a tensão V1, corrente I1, impedância Z e admitâncias Ya e Yb.

    **Parâmetros:**\n
    V1 (complex): T\n
    ensão no terminal transmissor\n
    I1 (complex): Corrente no terminal transmissor\n
    Z (complex): Impedância em série\n
    Ya (complex): Admitância shunt na entrada\n
    Yb (complex): Admitância shunt na saída\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    (V2, I2) - Tensão e corrente no terminal receptor
    """

    import numpy as np

    # Utilizando a função existente para calcular os parâmetros ABCD
    A, B, C, D = cte_gener(Z, Ya, Yb)

    # Resolvendo para V2 e I2 usando a equação matricial
    matriz_abcd = np.array([[A, B], [C, D]])
    vetor_v1_i1 = np.array([V1, I1])
    V2, I2 = np.linalg.solve(matriz_abcd, vetor_v1_i1)

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada:', ''),
            ("V1 = ", format_complex(V1)),
            ("I1 = ", format_complex(I1)),
            ("Z  = ", format_complex(Z)),
            ("Ya = ", format_complex(Ya)),
            ("Yb = ", format_complex(Yb)),
            ('\nResultados:', ''),
            ("V2 = ", format_complex(V2)),
            ("I2 = ", format_complex(I2))
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(nomearq, "Resultados do Circuito Pi", calculos)

    return V2, I2


def delta2estrela(zab, zbc, zca, nomearq=None):
    """
    # Converte um circuito delta em estrela.

    **Parâmetros:**\n
    zab, zbc, zca (complex): Impedâncias de fase do circuito delta\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    Uma tupla (za, zb, zc) com ai impedâncias de fase do circuito estrela
    """

    # Cálculo das impedâncias de fase do circuito delta
    zt = zab + zbc + zca
    za = (zab * zbc) / zt
    zb = (zbc * zca) / zt
    zc = (zca * zab) / zt

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada: ', '(Impedancias de fase em Delta)'),
            ("Zab = ", format_complex(zab)),
            ("Zbc = ", format_complex(zbc)),
            ("Zca = ", format_complex(zca)),
            ('\nResultados: ', '(Impedancias de fase em Estrela)'),
            ("Za = ", format_complex(za)),
            ("Zb = ", format_complex(zb)),
            ("Zc = ", format_complex(zc))
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(
            nomearq, "Resultados da Conversão Delta-Estrela", calculos)

    return za, zb, zc


def estrela2delta(za, zb, zc, nomearq=None):
    """
    # Converte um circuito estrela em delta.\n

    **Parâmetros:**\n
    za, zb, zc (complex): Impedâncias de fase do circuito estrela\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    (zab, zbc, zca) - Impedâncias de fase do circuito delta
    """

    # Cálculo das impedâncias de fase do circuito estrela
    z_num = za * zb + zb * zc + zc * za
    zab = z_num / zb
    zbc = z_num / zc
    zca = z_num / za

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada:', '(Impedancias de fase em Estrela)'),
            ("Za = ", format_complex(za)),
            ("Zb = ", format_complex(zb)),
            ("Zc = ", format_complex(zc)),
            ('\nResultados:', '(Impedancias de fase em Delta)'),
            ("Zab = ", format_complex(zab)),
            ("Zbc = ", format_complex(zbc)),
            ("Zca = ", format_complex(zca))
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(
            nomearq, "Resultados da Conversão Estrela-Delta", calculos)

    return zab, zbc, zca


def queda1f(Ic, DVc, Lc, Vfn, nomearq=None):
    """
    # Calcula a seção do condutor (Sc) para um circuito monofásico em cobre.

    **Parâmetros:**\n
    Ic (float): Corrente total do circuito em A.\n
    DVc (float): Queda de tensão máxima admitida em %.\n
    Lc (float): Comprimento total do circuito em metros.\n
    Vfn (float): Tensão fase-neutro em volts.\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    Sc (float): Seção do condutor em mm².
    """
    # Resistividade do cobre em Ω.mm²/m
    rho = 1 / 56

    # Cálculo da seção do condutor
    Sc = (200 * rho * (Lc * Ic)) / (DVc * Vfn)

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada:', ''),
            ("Ic = ", f"{Ic} A"),
            ("DVc = ", f"{DVc} %"),
            ("Lc = ", f"{Lc} m"),
            ("Vfn = ", f"{Vfn} V"),
            ("\nSeção do condutor (Sc) = ", f"{Sc:.2f} mm²")
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(
            nomearq, "Cálculo da Queda de Tensão Monofásica", calculos)

    return Sc


def queda3f(Ic, DVc, Lc, Vfn, nomearq=None):
    """
    # Calcula a seção do condutor (Sc) para um circuito trifásico em cobre.

    **Parâmetros:**\n
    Ic (float): Corrente total do circuito em A.\n
    DVc (float): Queda de tensão máxima admitida em %.\n
    Lc (float): Comprimento total do circuito em metros.\n
    Vfn (float): Tensão fase-neutro em volts.\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    Sc (float): Seção do condutor em mm².
    """
    # Resistividade do cobre em Ω.mm²/m
    rho = 1 / 56

    # Cálculo da seção do condutor
    Sc = (173.2 * rho * (Lc * Ic)) / (DVc * Vfn)

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada:', ''),
            ("Ic = ", f"{Ic} A"),
            ("DVc = ", f"{DVc} %"),
            ("Lc = ", f"{Lc} m"),
            ("Vfn = ", f"{Vfn} V"),
            ("\nSeção do condutor (Sc) = ", f"{Sc:.2f} mm²")
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(
            nomearq, "Cálculo da Queda de Tensão Trifásica", calculos)

    return Sc


def vfonte(Vc, Z, Sc, nomearq=None):
    """
    # Calcula a tensão na fonte e a corrente do alimentador.

    **Parâmetros:**\n
    Vc (tupla): Tensão na carga (módulo e fase, em graus).\n
    Z (tupla): Impedância do alimentador (R e X, em ohms).\n
    Sc (tupla): Potência complexa da carga (Pc e Qc, em VA).\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    (Vf, I) - Tensão na fonte e corrente do alimentador.
    """
    # Converter entrada para forma retangular
    Vc_rect = pol2ret(*Vc, unidade='g')
    Z_rect = complex(*Z)  # Impedância já está em forma retangular
    Sc_rect = complex(*Sc)  # Potência complexa

    # Calcular corrente no alimentador
    I = Sc_rect.conjugate() / Vc_rect  # I = S*/V

    # Calcular tensão na fonte
    Vf_rect = Vc_rect + I * Z_rect

    # Converter resultados para polar
    Vf_polar = ret2pol(Vf_rect, unidade='g')
    I_polar = ret2pol(I, unidade='g')

    # Se nomearq for fornecido, salvar os resultados no arquivo
    if nomearq:
        calculos = [
            ('Dados de Entrada:', ''),
            ("Vc = ", format_complex(Vc_rect, 'p')),
            ("Z = ", format_complex(Z_rect, 'r')),
            ("Sc = ", format_complex(Sc_rect, 'r')),
            ('\nResultados:', ''),
            ("Vf = ", format_complex(Vf_rect, 'p')),
            ("I = ", format_complex(I, 'p'))
        ]

        gerar_arquivo_texto(nomearq, "Cálculo da Tensão na Fonte", calculos)

    return Vf_polar, I_polar


def vfontepi(Vc, Z, Ya, Yb, Sc, nomearq=None):
    """
    # Calcula a tensão na fonte e a corrente do alimentador para um circuito Pi.

    **Parâmetros:**\n
    Vc (tupla): Tensão na carga (módulo e fase, em graus).\n
    Z (tupla): Impedância do alimentador (R e X, em ohms).\n
    Ya (tupla): Admitância no lado da fonte (G e B, em S).\n
    Yb (tupla): Admitância no lado da carga (G e B, em S).\n
    Sc (tupla): Potência complexa da carga (Pc e Qc, em VA).\n
    nomearq (str, opcional): Nome do arquivo de saída. Padrão é None.

    **Retorno:**\n
    (Vf, I) - Tensão na fonte e corrente do alimentador.
    """
    # Converter entradas para forma retangular
    Vc_ret = pol2ret(*Vc, unidade='g') if isinstance(Vc, tuple) else Vc
    Z_ret = complex(*Z) if isinstance(Z, tuple) else Z
    Ya_ret = complex(*Ya) if isinstance(Ya, tuple) else Ya
    Yb_ret = complex(*Yb) if isinstance(Yb, tuple) else Yb
    Sc_ret = complex(*Sc) if isinstance(Sc, tuple) else Sc

    # Calcular corrente no alimentador
    I = Sc_ret.conjugate() / Vc_ret  # I = S*/V

    # Determinar admitância total
    Y_total = Ya_ret + Yb_ret

    # Calcular tensão na fonte considerando a impedância do alimentador
    Vf_ret = Vc_ret + (I * Z_ret) + (I / Y_total)

    # Converter resultados para forma polar
    Vf_polar = ret2pol(Vf_ret, unidade='g')
    I_polar = ret2pol(I, unidade='g')

    # Salvar os resultados no arquivo se nomearq for fornecido
    if nomearq:
        calculos = [
            ('Dados de Entrada:', ''),
            ("Vc = ", format_complex(Vc_ret, 'p')),
            ("Z = ", format_complex(Z_ret, 'r')),
            ("Ya = ", format_complex(Ya_ret, 'r')),
            ("Yb = ", format_complex(Yb_ret, 'r')),
            ("Sc = ", format_complex(Sc_ret, 'r')),
            ('\nResultados:', ''),
            ("Vf = ", format_complex(Vf_ret, 'p')),
            ("I = ", format_complex(I, 'p'))
        ]
        gerar_arquivo_texto(
            nomearq, "Cálculo da Tensão na Fonte para Circuito Pi", calculos)

    return Vf_polar, I_polar


def impcabo(secao_bt, nomearq=None):
    """
    # Calcula a impedância do cabo de cobre com isolação de PVC em Ω/km.

    **Parâmetros:**\n
    secao_bt (float): Seção do condutor em mm².\n
    nomearq (str, opcional): Nome do arquivo para salvar os resultados. None por padrão.

    **Retorno:**\n
    A impedância do cabo de cobre em Ω/km.
    """
    # Tabela de resistência e reatância (em mΩ/m)
    tabela_cabos = {
        1: (22.1, 0.176), 1.5: (14.8, 0.168), 2.5: (8.91, 0.155),
        4: (5.57, 0.143), 6: (3.71, 0.135), 10: (2.24, 0.119),
        16: (1.41, 0.112), 25: (0.880, 0.106), 35: (0.841, 0.101),
        50: (0.473, 0.101), 70: (0.328, 0.0965), 95: (0.236, 0.0975),
        120: (0.188, 0.0939), 150: (0.153, 0.0928), 185: (0.123, 0.0908),
        240: (0.0943, 0.0902), 300: (0.0761, 0.0895), 400: (0.0607, 0.0876),
        500: (0.0496, 0.0867), 630: (0.0402, 0.0865)
    }

    # Verificar se a seção nominal está na tabela
    if secao_bt not in tabela_cabos:
        raise ValueError(
            f"Seção nominal não encontrada na tabela. Favor selecionar entre: {', '.join(map(str, tabela_cabos.keys()))} mm².")

    # Obter resistência e reatância
    resistencia, reatancia = tabela_cabos[secao_bt]
    impedancia = complex(resistencia, reatancia)  # Convertendo para Ω/km

    # Criar lista de cálculos formatados para salvar no arquivo
    if nomearq:
        calculos = [
            ("Seção do condutor (Sc) = ", f"{secao_bt} mm²"),
            ('Impedância do cabo = ',
             f"{format_complex(impedancia, 'r', 3)} Ω/km")
        ]

        # Salvar os resultados no arquivo desejado
        gerar_arquivo_texto(
            nomearq, "Cálculo da Impedância do Cabo de Cobre", calculos)

    return impedancia


def inst2fasor(amplitude, angulo, tipo='cos', unidade='g'):
    """
    # Converte uma corrente ou tensão instantânea para fasor na forma retangular e polar.

    **Parâmetros:**\n   
    amplitude (float): Amplitude da corrente.\n
    angulo (float): Ângulo de fase (em graus, se unidade='g', ou radianos, se unidade='r').\n
    tipo (str): 'cos' se for baseado no cosseno, 'sin' se for baseado no seno.\n
    unidade (str): 'g' para graus (default), 'r' para radianos.\n

    **Retorno:**\n
    tuple: Fasor na forma retangular e polar.
    """
    from cmath import rect, polar
    from math import radians, degrees

    if unidade == 'g':
        angulo = radians(angulo)  # Converte para radianos se necessário

    if tipo == 'sin':
        angulo -= radians(90)  # Converte seno para cosseno subtraindo 90°

    # Representação retangular
    fasor_ret = rect(amplitude, angulo)

    # Representação polar
    modulo, fase = polar(fasor_ret)
    if unidade == 'g':
        fase = degrees(fase)  # Converte de volta para graus

    return fasor_ret, (modulo, fase)


def plot_fasor(*fasores, nome_arquivo=None):
    """
    # Plota um diagrama fasorial e salva a imagem.

    **Parâmetros:**\n
    nome_arquivo (str): Nome do arquivo para salvar a imagem do diagrama.\n
    *fasores (tuplas): Lista de fasores no formato (valor, label).

    **Retorno:**\n
    Gera e salva um diagrama fasorial com os fasores fornecidos.
    """
    import matplotlib.pyplot as plt
    import random

    plt.figure()

    cores = ["r", "g", "b", "m", "c", "y", "k"]  # Lista de 7 cores fixas
    random.shuffle(cores)  # Embaralha as cores para garantir variedade

    for (fasor, rotulo), cor in zip(fasores, cores):
        if fasor:  # Verifica se o fasor não é vazio
            plt.arrow(0, 0, fasor.real, fasor.imag, head_width=0.5,
                      head_length=0.5, color=cor, label=rotulo)

    plt.xlim(-15, 15)
    plt.ylim(-15, 15)
    plt.axhline(0, color='black', linewidth=0.5)
    plt.axvline(0, color='black', linewidth=0.5)
    plt.grid(True, linestyle='--', linewidth=0.5)
    plt.legend()
    plt.title("Diagrama Fasorial")
    plt.xlabel("Parte Real")
    plt.ylabel("Parte Imaginária")

    # Salvar a imagem se nome_arquivo for fornecido
    if nome_arquivo:
        plt.savefig(nome_arquivo)
        print(f"Diagrama fasorial salvo como {nome_arquivo}")
    plt.show()


def fator_potencia(V=None, I=None, Zeq=None, S=None, P=None, mod_S=None):
    """
    # Calcula o fator de potência a partir de diferentes combinações de parâmetros.

    **Parâmetros:**\n
    V (complex, opcional): Tensão do circuito (número complexo).\n
    I (complex, opcional): Corrente do circuito (número complexo).\n
    Zeq (complex, opcional): Impedância equivalente do circuito (número complexo).\n
    S (complex, opcional): Potência aparente (VA).\n
    P (float, opcional): Potência ativa (W).\n
    mod_S (float, opcional): Módulo da potência aparente (VA).\n
    **Retorno:**\n
    FP (float): Fator de potência (0 a 1), indicando a eficiência da utilização da potência.
    """
    if S is None:
        if V is not None and I is not None:
            S = V * I.conjugate()  # Calcula potência aparente se V e I forem fornecidos
        elif mod_S is not None:
            S = mod_S  # Usa diretamente o módulo de S, se fornecido
        else:
            raise ValueError(
                "Para calcular o fator de potência sem S, forneça V e I ou o módulo de S.")

    if P is None:
        if isinstance(S, complex):
            P = S.real  # Usa a parte real de S como potência ativa se P não for fornecido
        else:
            raise ValueError(
                "Para calcular o fator de potência sem P, forneça P ou um S complexo.")

    if abs(S) == 0:
        raise ValueError("A potência aparente não pode ser zero.")

    FP = abs(P) / abs(S)
    return FP


def calc_banco_capacitor(P, FP_inicial, FP_final, V, f):
    """
    # Calcula a capacitância necessária para correção do fator de potência.

    **Parâmetros:**\n
    P (float): Potência ativa em watts (W)\n
    FP_inicial (float): Fator de potência inicial (adimensional)\n
    FP_final (float): Fator de potência final desejado (adimensional)\n
    V (float): Tensão em volts (V)\n
    f (float): Frequência em hertz (Hz)\n

    **Retorna:**\n
    float: Capacitância necessária em microfarads (μF)
    """
    from math import pi

    # Calcula a potência reativa necessária para correção
    Qc = Qcor_pot(P, FP_inicial, FP_final)

    # Cálculo da capacitância necessária
    Xc = V**2 / Qc  # Reatância capacitiva
    C = 1 / (2 * pi * f * Xc)  # Capacitância em farads

    return C * 1e6  # Convertendo para microfarads (μF)


def mudar_base(pu_antigo, S_base_antiga, S_base_nova, V_base_antiga, V_base_nova, tipo="z"):
    """
    # Calcula a impedância ou a corrente em pu após mudança de base.

    **Parâmetros:**
    pu_antigo (float): Impedância ou corrente em pu na base antiga\n
    S_base_antiga (float): Potência base antiga em VA\n
    S_base_nova (float): Potência base nova em VA\n
    V_base_antiga (float): Tensão base antiga em V\n
    V_base_nova (float): Tensão base nova em V\n
    tipo (str): Escolhe o tipo de cálculo: "z" para impedancia ou "i" para corrente\n

    **Retorno:**\n
    float: Nova impedância ou nova corrente em pu, dependendo do tipo selecionado
    """
    # Cálculo da impedância em pu
    if tipo == "z":
        pu_novo = pu_antigo * (S_base_nova / S_base_antiga) * \
            ((V_base_antiga ** 2) / (V_base_nova ** 2))

    # Cálculo da corrente em pu
    elif tipo == "i":
        pu_novo = pu_antigo * (S_base_antiga / S_base_nova) * \
            (V_base_nova / V_base_antiga)

    else:
        raise ValueError(
            "Tipo inválido. Escolha 'z' para impedancia ou 'i' para corrente.")

    return pu_novo


def calcular_potencias(mva, fp):
    """
    Calcula a potência ativa (W) e reativa (Var) a partir de MVA e FP.

    Parâmetros:
    mva (float): Potência aparente em MVA (Mega Volt-Amperes).
    fp (float): Fator de potência (0 a 1).

    Retorna:
    tuple: Potência ativa em MW (Megawatts) e potência reativa em MVAr (Mega Volt-Amps reativos).
    """
    mw = mva * fp  # Potência ativa em MW
    mvar = mva * (1 - fp**2)**0.5  # Potência reativa em MVAr
    return mw, mvar


class SistemaEletrico:
    """
    Classe para modelagem de sistemas elétricos.

    Permite criar uma representação de um sistema elétrico com N barras e seus ramos,
    e realizar cálculos como matriz de admitância de barra (Ybus), matriz de impedância
    de barra (Zbus), e cálculo de fluxos.

    A numeração das barras segue a convenção 1-based, com a barra 0 representando
    a referência (terra) externa ao sistema.
    """

    def __init__(self, num_barras):
        """
        Inicializa um sistema elétrico com o número especificado de barras.

        Permite criar uma representação de um sistema elétrico com N barras e seus ramos,
        e realizar cálculos como matriz de admitância de barra (Ybus), matriz de impedância
        de barra (Zbus), e cálculo de fluxos.

        **Parâmetros:**\n
        num_barras (int): Número de barras do sistema, excluindo a referência.

        **Levanta:**\n
        ValueError: Se o número de barras for negativo.
        """
        self.nb = int(num_barras)
        if self.nb < 0:
            raise ValueError("Número de barras deve ser >= 0")
        self.ramos = []  # Lista para armazenar os ramos do sistema

    def adicionar_ramo(self, *args, **kwargs):
        """
        Adiciona um ramo ao sistema elétrico com interface flexível.

        **Formatos aceitos:**\n
        - adicionar_ramo(de, para, zser, ysa=0j, ysb=0j, eram=0.0, faseramo=0.0, identif="")
        - Pode passar argumentos posicionais; se o último for string, é interpretado como identificador.
        - Se passar um único argumento iterável (lista/tupla), considera como linha completa de dados.

        **Parâmetros:**\n
        de (int): Número da barra de origem (1-based, 0 = referência)
        para (int): Número da barra de destino (1-based, 0 = referência)
        zser (complex): Impedância série do ramo
        ysa (complex, opcional): Admitância shunt no início do ramo. Padrão: 0j
        ysb (complex, opcional): Admitância shunt no fim do ramo. Padrão: 0j
        eram (float, opcional): Módulo da tensão interna (fonte). Padrão: 0.0
        faseramo (float, opcional): Ângulo da tensão interna em graus. Padrão: 0.0
        identif (str, opcional): Identificador do ramo. Padrão: ""

        **Retorno:**\n
        SistemaEletrico: O próprio objeto (para permitir chamadas encadeadas)

        **Levanta:**\n
        ValueError: Se parâmetros mínimos (de, para, zser) não forem fornecidos.
        """
        # Se passou um único iterable (lista/tuple), desempacotamos
        pos = []
        if len(args) == 1 and not isinstance(args[0], (str, bytes)) and hasattr(args[0], "__iter__"):
            pos = list(args[0])
        else:
            pos = list(args)

        # Se último pos é string, interpretamos como identif
        identif = kwargs.get("identif", "")
        if len(pos) and isinstance(pos[-1], str):
            identif = pos.pop(-1)

        # Mapear posição por ordem esperada:
        # de, para, zser, ysa, ysb, eram, faseramo
        de = kwargs.get("de", None)
        para = kwargs.get("para", None)
        zser = kwargs.get("zser", None)
        ysa = kwargs.get("ysa", 0j)
        ysb = kwargs.get("ysb", 0j)
        eram = kwargs.get("eram", 0.0)
        faseramo = kwargs.get("faseramo", 0.0)
        extras = []

        # Atribuir valores a partir de argumentos posicionais
        order = ["de", "para", "zser", "ysa", "ysb", "eram", "faseramo"]
        for i, name in enumerate(order):
            if i < len(pos):
                val = pos[i]
                # Converter para o tipo apropriado
                if name in ("de", "para"):
                    val = int(val)
                elif name in ("zser", "ysa", "ysb"):
                    val = complex(val)
                else:
                    val = float(val)

                # Atualizar variáveis locais
                if name == "de":
                    de = val
                elif name == "para":
                    para = val
                elif name == "zser":
                    zser = val
                elif name == "ysa":
                    ysa = val
                elif name == "ysb":
                    ysb = val
                elif name == "eram":
                    eram = val
                elif name == "faseramo":
                    faseramo = val

        # Armazenar quaisquer argumentos posicionais extras
        if len(pos) > len(order):
            extras = pos[len(order):]

        # Verificar se parâmetros mínimos foram fornecidos
        if de is None or para is None or zser is None:
            raise ValueError(
                "Parâmetros mínimos de ramo: de, para, zser (ou passe uma sequência compatível).")

        # Criar dicionário do ramo e adicionar à lista
        ramo = {
            "de": int(de),
            "para": int(para),
            "zser": complex(zser),
            "ysa": complex(ysa),
            "ysb": complex(ysb),
            "eram": float(eram),
            "faseramo": float(faseramo),
            "identif": str(identif),
            "extras": extras
        }
        self.ramos.append(ramo)
        return self  # Retorna self para permitir chamadas encadeadas

    def calcular_matrizes_rede(self):
        """
        Calcula as matrizes de admitância nodal (Ybus) e impedância nodal (Zbus).

        Constrói a matriz Ybus com base nos parâmetros dos ramos do sistema e
        calcula a Zbus como a inversa da Ybus.

        **Retorno:**\n
        tuple: Uma tupla contendo:
            - Ybus (numpy.ndarray): Matriz de admitância de barra [nb x nb]
            - Zbus (numpy.ndarray): Matriz de impedância de barra [nb x nb]
            - Bi (numpy.ndarray): Vetor de barras de origem dos ramos [nr]
            - Bf (numpy.ndarray): Vetor de barras de destino dos ramos [nr]
            - Zser (numpy.ndarray): Vetor de impedâncias série dos ramos [nr]
            - Yser (numpy.ndarray): Vetor de admitâncias série dos ramos [nr]
            - Ysa (numpy.ndarray): Vetor de admitâncias shunt no início dos ramos [nr]
            - Ysb (numpy.ndarray): Vetor de admitâncias shunt no fim dos ramos [nr]
        """
        import numpy as np

        nb = self.nb
        nr = len(self.ramos)

        # Inicialização dos vetores
        Bi = np.zeros(nr, dtype=np.int64)
        Bf = np.zeros(nr, dtype=np.int64)
        Ysa = np.zeros(nr, dtype=complex)
        Ysb = np.zeros(nr, dtype=complex)
        Zser = np.zeros(nr, dtype=complex)
        Yser = np.zeros(nr, dtype=complex)
        Identif = [""] * nr
        Ybus = np.zeros((nb, nb), dtype=complex)

        # Preencher os arrays com os dados dos ramos
        for i, r in enumerate(self.ramos):
            Bi[i] = int(r["de"])
            Bf[i] = int(r["para"])
            Zser[i] = complex(r["zser"])
            Yser[i] = 1.0/Zser[i] if Zser[i] != 0 else 0
            Ysa[i] = complex(r.get("ysa", 0j))
            Ysb[i] = complex(r.get("ysb", 0j))
            Identif[i] = r.get("identif", "")

        # Montagem da matriz Ybus exatamente como no código original
        for j in range(nr):
            L = Bi[j]
            M = Bf[j]
            if (M != 0) and (L != 0):
                L = L - 1
                M = M - 1
                Ybus[L, L] = Ybus[L, L] + Yser[j] + Ysa[j]
                Ybus[M, M] = Ybus[M, M] + Yser[j] + Ysb[j]
                Ybus[L, M] = Ybus[L, M] - Yser[j]
                Ybus[M, L] = Ybus[M, L] - Yser[j]
            if (L == 0) and (M != 0):
                M = M - 1
                Ybus[M, M] = Ybus[M, M] + Yser[j] + Ysa[j]
            if (M == 0) and (L != 0):
                L = L - 1
                Ybus[L, L] = Ybus[L, L] + Yser[j] + Ysb[j]

        # Cálculo de Zbus
        Zbus = None
        try:
            Zbus = np.linalg.inv(Ybus)
        except np.linalg.LinAlgError:
            Zbus = None

        return Ybus, Zbus, Bi, Bf, Zser, Yser, Ysa, Ysb

    def calcular_parametros_rede(self):
        """
        Calcula os parâmetros elétricos da rede: correntes de injeção, 
        tensões nodais e correntes nos ramos.

        **Retorno:**\n
        tuple: Uma tupla contendo:
            - Isi (numpy.ndarray): Vetor de injeções de corrente nas barras [nb x 1]
            - Vsi (numpy.ndarray): Vetor de tensões nodais [nb x 1]
            - i_ramo (numpy.ndarray): Vetor de correntes nos ramos [nr x 1]
            - Eramo (numpy.ndarray): Vetor de módulos das tensões internas [nr]
            - Faseramo (numpy.ndarray): Vetor de ângulos das tensões internas em graus [nr]
            - Bi (numpy.ndarray): Vetor de barras de origem dos ramos [nr]
            - Bf (numpy.ndarray): Vetor de barras de destino dos ramos [nr]
            - Zser (numpy.ndarray): Vetor de impedâncias série dos ramos [nr]
        """
        import numpy as np
        from cmath import rect
        from math import radians

        nb = self.nb
        nr = len(self.ramos)

        Eramo = np.zeros(nr, dtype=float)
        Faseramo = np.zeros(nr, dtype=float)

        for i, r in enumerate(self.ramos):
            Eramo[i] = float(r.get("eram", 0.0))
            Faseramo[i] = float(r.get("faseramo", 0.0))

        # Obtém as matrizes da rede
        Ybus, Zbus, Bi, Bf, Zser, Yser, Ysa, Ysb = self.calcular_matrizes_rede()

        nb = self.nb
        nr = len(self.ramos)

        # Cálculo de Isi
        Isi = np.zeros((nb, 1), dtype=complex)
        for k in range(nr):
            if Bi[k] == 0:
                Isi[Bf[k]-1, 0] = rect(Eramo[k], radians(Faseramo[k]))/Zser[k]
            if Bf[k] == 0:
                Isi[Bi[k]-1, 0] = rect(Eramo[k], radians(Faseramo[k]))/Zser[k]

        # Cálculo de Vsi
        Vsi = np.zeros((nb, 1), dtype=complex)
        if Zbus is not None:
            Vsi = Zbus @ Isi

        # Cálculo das correntes nos ramos
        i_ramo = np.zeros((nr, 1), dtype=complex)
        for m in range(nr):
            a = Bf[m] - 1
            b = Bi[m] - 1
            if Bf[m] != 0 and Bi[m] != 0:
                i_ramo[m, 0] = (Vsi[b, 0] - Vsi[a, 0]) / Zser[m]
            elif Bi[m] == 0:
                i_ramo[m, 0] = (-Vsi[a, 0]) / Zser[m]
            elif Bf[m] == 0:
                i_ramo[m, 0] = Vsi[b, 0] / Zser[m]

        return Isi, Vsi, i_ramo, Eramo, Faseramo, Bi, Bf, Zser

    def obter_ramos(self):
        """
        Retorna um único dicionário consolidado com os dados de todos os ramos do sistema.

        O dicionário retornado possui como chaves os nomes dos parâmetros dos ramos 
        ('de', 'para', 'zser', etc.) e como valores listas contendo todos os valores 
        correspondentes de cada ramo, na ordem em que foram adicionados.

        **Retorno:**\n
        dict: Dicionário com as seguintes chaves, cada uma contendo uma lista de valores:
        - 'de': barras de origem
        - 'para': barras de destino
        - 'zser': impedâncias série
        - 'ysa': admitâncias shunt no início dos ramos
        - 'ysb': admitâncias shunt no fim dos ramos
        - 'eram': módulos das tensões internas (fontes)
        - 'faseramo': ângulos das tensões internas em graus
        - 'identif': identificadores dos ramos
        - 'extras': listas de valores extras fornecidos
        """
        # Inicializa o dicionário com listas vazias para cada chave
        ramos_dict = {
            'de': [], 'para': [], 'zser': [], 'ysa': [], 'ysb': [],
            'eram': [], 'faseramo': [], 'identif': [], 'extras': []
        }

        # Preenche as listas com os valores de cada ramo
        for ramo in self.ramos:
            for key in ramos_dict:
                ramos_dict[key].append(ramo[key])

        return ramos_dict


def fluxocarga(V1, z, yshunt, S, Kp=1.0, Ki=0.0, Kz=0.0):
    """
    Calcula a tensão na barra 2 (receptora) em um sistema de duas barras
    com linha de transmissão no modelo π e carga do tipo ZIP (constante potência,
    constante corrente e constante impedância).

    Parâmetros:
        V1     : tensão na barra transmissora (pu, número complexo)
        z      : impedância série da linha (pu, número complexo)
        yshunt : admitância shunt total da linha (pu, número complexo)
        S      : potência aparente da carga a 1 pu de tensão (P+jQ) (pu, número complexo)
        Kp     : fração da carga de potência constante   (0 ≤ Kp ≤ 1)
        Ki     : fração da carga de corrente constante   (0 ≤ Ki ≤ 1)
        Kz     : fração da carga de impedância constante (0 ≤ Kz ≤ 1)
                (Kp + Ki + Kz = 1)
    Retorno:
        V2     : tensão complexa na barra receptora (pu, número complexo)
    """

    import numpy as np
    from scipy.optimize import fsolve

    # Admitância série da linha
    Yserie = 1 / z

    # Admitância shunt é dividida entre as duas extremidades da linha (modelo π)
    Ysh_metade = yshunt / 2

    # Montagem da matriz Ybus do sistema de duas barras
    Ybus = np.array([[Yserie + Ysh_metade,           -Yserie],
                     [-Yserie,             Yserie + Ysh_metade]])

    # Função das equações não lineares (aplicada em fsolve)
    def equacoes(variaveis):
        Vr, Vi = variaveis  # componente real e imaginária de V2
        V2 = Vr + 1j*Vi     # tensão complexa na barra 2

        # Corrente fornecida pela rede ao nó 2
        I_rede = Ybus[1, 0]*V1 + Ybus[1, 1]*V2

        # Potência da carga conforme modelo ZIP
        Scarga = Kp * S
        Scarga += Ki * S * abs(V2)
        Scarga += Kz * S * (abs(V2)**2)

        # Corrente da carga (Icarga = conj(Scarga / V2))
        I_carga = np.conj(Scarga / V2)

        # Equação de balanço de corrente na barra 2
        # Corrente da rede + Corrente da carga = 0
        Ibal = I_rede + I_carga

        return [np.real(Ibal), np.imag(Ibal)]

    # Valor inicial (chute) para o fsolve: tensão próxima de 1 pu
    V2_inicial = [1.0, 0.0]
    sol = fsolve(equacoes, V2_inicial)

    return sol[0] + 1j*sol[1]


class ParametrosLinha:
    """
    Classe para cálculo de parâmetros de linhas de transmissão.

    Attributes:
        dados (dict): Dicionário contendo todos os parâmetros da linha
        frequencia (float): Frequência do sistema (Hz)
        mu_0 (float): Permeabilidade magnética do vácuo
        k (float): Constante de Carson simplificada
    """

    def __init__(self, dados):
        """
        Inicializa a classe com os dados da linha.

        Parameters:
            dados (dict): Dicionário contendo parâmetros da linha
        """
        self.dados = dados
        self.frequencia = dados.get('frequencia', [60])[0]
        self.mu_0 = 4 * np.pi * 1e-7 * (1/1000)  # H/km
        self.k = 2 * 1e-7  # Constante de Carson simplificada

    def resistencia_corrigida(self, r0, t0, t1):
        """
        Calcula a resistência corrigida pela temperatura para um condutor.

        Parameters:
            r0 (float): Resistência do condutor na temperatura t0 (Ω/km)
            t0 (int): Temperatura de referência (°C)
            t1 (int): Temperatura desejada (°C)

        Returns:
            float: Resistência corrigida para a temperatura t1 (Ω/km)
        """
        r1 = r0 * (228 + t1) / (228 + t0)
        return r1

    def resistencia_corrigida_dict(self, t1):
        """
        Calcula a resistência corrigida usando dados do dicionário interno.

        Parameters:
            t1 (int): Temperatura desejada (°C)

        Returns:
            float or None: Resistência corrigida ou None em caso de erro
        """
        try:
            if 'r0' not in self.dados or 't0' not in self.dados:
                raise KeyError(
                    "Chaves 'r0' e/ou 't0' não encontradas no dicionário")

            if not self.dados['r0'] or not self.dados['t0']:
                raise ValueError("Listas 'r0' e/ou 't0' estão vazias")

            r0 = self.dados['r0'][0]
            t0 = self.dados['t0'][0]

            return self.resistencia_corrigida(r0, t0, t1)

        except (KeyError, ValueError, IndexError) as e:
            print(f"Erro: {e}")
            return None

    def altura_efetiva_flecha(self, h, flecha):
        """
        Calcula a altura efetiva considerando a flecha do condutor.

        Parameters:
            h (float): Altura do condutor (m)
            flecha (float): Flecha do condutor (m)

        Returns:
            float: Altura efetiva (m)
        """
        h_efetiva = h - (2/3) * flecha
        return h_efetiva

    def ajustar_alturas_flecha(self):
        """
        Ajusta as alturas dos condutores considerando a flecha.
        Modifica o dicionário interno de dados.
        """
        if 'Flecha' in self.dados and 'Y' in self.dados:
            flecha = self.dados['Flecha'][0]
            for i in range(len(self.dados['Y'])):
                h = self.dados['Y'][i]
                self.dados['Y'][i] = self.altura_efetiva_flecha(h, flecha)

    def resistencia_feixe(self, r, numero_condutores):
        """
        Calcula a resistência efetiva de um feixe de condutores.

        Parameters:
            r (float): Resistência de um condutor (Ω/km)
            numero_condutores (int): Número de condutores no feixe

        Returns:
            float: Resistência efetiva do feixe (Ω/km)
        """
        r_efetiva = r / numero_condutores
        return r_efetiva

    @staticmethod
    def distancia(X1, Y1, X2, Y2):
        """
        Calcula a distância euclidiana entre dois pontos.

        Parameters:
            X1, Y1 (float): Coordenadas do ponto 1
            X2, Y2 (float): Coordenadas do ponto 2

        Returns:
            float: Distância entre os pontos
        """
        return np.sqrt((X1 - X2)**2 + (Y1 - Y2)**2)

    def calcular_impedancias_proprias_mutuas(self, ra, rb, rc, Dab, Dac, Dbc, Ds):
        """
        Calcula impedâncias próprias e mútuas (sem condutor imagem).

        Parameters:
            ra, rb, rc (float): Resistências das fases A, B, C (Ω/km)
            Dab, Dac, Dbc (float): Distâncias entre fases (m)
            Ds (float): Raio médio geométrico do condutor (m)

        Returns:
            tuple: (Z_aa, Z_bb, Z_cc, Z_ab, Z_ac, Z_bc)
        """
        def Z_propria(r, Ds):
            X = 1j * self.k * np.log(1/Ds)
            return r + X

        def Z_mutua(Dij):
            X = 1j * self.k * np.log(1/Dij)
            return X

        Z_aa = Z_propria(ra, Ds)
        Z_bb = Z_propria(rb, Ds)
        Z_cc = Z_propria(rc, Ds)
        Z_ab = Z_mutua(Dab)
        Z_ac = Z_mutua(Dac)
        Z_bc = Z_mutua(Dbc)

        return Z_aa, Z_bb, Z_cc, Z_ab, Z_ac, Z_bc

    def calcular_impedancias_proprias_mutuas_CI(self, ra, rb, rc, Dab, Dac, Dbc,
                                                Ds, ha, hb, hc):
        """
        Calcula impedâncias próprias e mútuas com condutor imagem (Carson).

        Parameters:
            ra, rb, rc (float): Resistências das fases A, B, C (Ω/km)
            Dab, Dac, Dbc (float): Distâncias entre fases (m)
            Ds (float): Raio médio geométrico do condutor (m)
            ha, hb, hc (float): Alturas dos condutores A, B, C (m)

        Returns:
            tuple: (Z_aa, Z_bb, Z_cc, Z_ab, Z_ac, Z_bc)
        """
        def Z_propria(r, Ds, h):
            X = 1j * self.frequencia * self.mu_0 * np.log(2*h/Ds)
            return r + X

        def Z_mutua(dij, h):
            Dij = np.sqrt(dij**2 + h**2)
            X = 1j * self.frequencia * self.mu_0 * np.log(Dij/dij)
            return X

        Z_aa = Z_propria(ra, Ds, ha)
        Z_bb = Z_propria(rb, Ds, hb)
        Z_cc = Z_propria(rc, Ds, hc)
        Z_ab = Z_mutua(Dab, ha)
        Z_ac = Z_mutua(Dac, hb)
        Z_bc = Z_mutua(Dbc, hc)

        return Z_aa, Z_bb, Z_cc, Z_ab, Z_ac, Z_bc

    def matrix_Zlt(self, r, com_condutor_imagem=True):
        """
        Calcula a matriz ZLT para linhas de transmissão.

        Parameters:
            r (float): Resistência do condutor (Ω/km)
            com_condutor_imagem (bool): Se True, usa condutor imagem

        Returns:
            numpy.ndarray: Matriz 3x3 de impedâncias
        """
        Xc = self.dados['X']
        Yc = self.dados['Y']
        RMG = self.dados['RMG'][0]

        ZLT = np.zeros((3, 3), dtype=complex)

        for i in range(3):
            for j in range(3):
                if j == i:
                    # Elementos da diagonal
                    if com_condutor_imagem:
                        d = self.distancia(Xc[i], Yc[i], Xc[i], -Yc[i])
                        ZLT[i][j] = r + 1j * 4 * np.pi * 1e-4 * \
                            self.frequencia * np.log(d / RMG)
                    else:
                        ZLT[i][j] = r + 1j * 4 * np.pi * 1e-4 * \
                            self.frequencia * np.log(1 / RMG)
                else:
                    # Elementos fora da diagonal
                    di = self.distancia(Xc[i], Yc[i], Xc[j], Yc[j])
                    if com_condutor_imagem:
                        dii = self.distancia(Xc[i], Yc[i], Xc[j], -Yc[j])
                        ZLT[i][j] = 1j * 4 * np.pi * 1e-4 * \
                            self.frequencia * np.log(dii / di)
                    else:
                        ZLT[i][j] = 1j * 4 * np.pi * 1e-4 * \
                            self.frequencia * np.log(1 / di)

        return ZLT

    def imprimir_matriz_Zlt(self, ZLT, com_condutor_imagem=True):
        """
        Imprime a matriz ZLT formatada.

        Parameters:
            ZLT (numpy.ndarray): Matriz de impedâncias
            com_condutor_imagem (bool): Indica se foi calculada com CI
        """
        titulo = 'Matrix ZLT' if com_condutor_imagem else 'Matrix ZLT SEM CI'
        print(f'    {titulo}')

        for i in range(3):
            for j in range(3):
                R = np.real(ZLT[i][j])
                X = np.imag(ZLT[i][j])
                A = i + 1
                B = j + 1
                if X >= 0.0:
                    print(f'    ZLT({A}d,{B}d) - {R:8.4f} + {X:8.4f}j ')
                else:
                    print(f'    ZLT({A}d,{B}d) - {R:8.4f} - {abs(X):8.4f}j ')

        print(48 * '*')

    def impedancia_fase(self, Z_aa, Z_bb, Z_cc, Z_ab, Z_ac, Z_bc):
        """
        Calcula a impedância de cada fase.

        Parameters:
            Z_aa, Z_bb, Z_cc (complex): Impedâncias próprias (Ω/km)
            Z_ab, Z_ac, Z_bc (complex): Impedâncias mútuas (Ω/km)

        Returns:
            tuple: (Z_a, Z_b, Z_c)
        """
        Z_a = Z_aa - (Z_ab + Z_ac) / 2
        Z_b = Z_bb - (Z_ab + Z_bc) / 2
        Z_c = Z_cc - (Z_ac + Z_bc) / 2

        return Z_a, Z_b, Z_c

    def Zserv(self, ZLT):
        """
        Calcula a impedância de serviço a partir da matriz ZLT.

        Parameters:
            ZLT (numpy.ndarray): Matriz 3x3 de impedâncias

        Returns:
            tuple: (Zs, Za, Zb, Zc) - impedância de serviço e por fase
        """
        Za = ZLT[0][0] - (1/2) * (ZLT[0][1] + ZLT[0][2])
        Zb = ZLT[1][1] - (1/2) * (ZLT[1][0] + ZLT[1][2])
        Zc = ZLT[2][2] - (1/2) * (ZLT[2][0] + ZLT[2][1])

        Zs = (Za + Zb + Zc) / 3

        return Zs, Za, Zb, Zc

    def impedancia_servico_linha_trifasica(self, Z_aa, Z_bb, Z_cc, Z_ab, Z_ac, Z_bc):
        """
        Calcula a matriz de impedância de serviço para linha trifásica não transposta.

        Parameters:
            Z_aa, Z_bb, Z_cc (complex): Impedâncias próprias (Ω/km)
            Z_ab, Z_ac, Z_bc (complex): Impedâncias mútuas (Ω/km)

        Returns:
            tuple: (Z_servico_array, Z_servico) - matriz e valor médio
        """
        Z_primitive = np.array([
            [Z_aa, Z_ab, Z_ac],
            [Z_ab, Z_bb, Z_bc],
            [Z_ac, Z_bc, Z_cc]
        ], dtype=complex)

        Z_servico_array = Z_primitive
        Z_servico = (Z_aa + Z_bb + Z_cc - Z_ab - Z_ac - Z_bc) / 3

        return Z_servico_array, Z_servico

# Newton Rapshon


def matriz_ybus(df_ybus):
    try:
        # Encontra o número de barras corretamente
        n_barras = int(max(df_ybus['de_barra'].max(),
                       df_ybus['para_barra'].max()))

        # Inicializa Ybus
        Ybus = np.zeros((n_barras, n_barras), dtype=complex)

        # Admissão série (y_ij) e shunt (y_sh)
        z_lt = df_ybus['r_lt'] + 1j * df_ybus['x_lt']
        y_lt_serie = 1.0 / z_lt
        # y_lt no seu dado parece ser o b_shunt
        y_lt_shunt = 1j * df_ybus['y_lt']

        # Itera UMA VEZ sobre as linhas de transmissão
        for idx in range(len(df_ybus)):
            # Índices base 0
            i = int(df_ybus.loc[idx, 'de_barra']) - 1
            j = int(df_ybus.loc[idx, 'para_barra']) - 1

            y_serie = y_lt_serie[idx]
            y_shunt_half = y_lt_shunt[idx] / 2.0  # Modelo PI

            # Elementos Fora-Diagonal (Y_ij e Y_ji)
            Ybus[i, j] = Ybus[i, j] - y_serie
            Ybus[j, i] = Ybus[i, j]  # Matriz é simétrica

            # Elementos Diagonais (Y_ii e Y_jj)
            Ybus[i, i] = Ybus[i, i] + y_serie + y_shunt_half
            Ybus[j, j] = Ybus[j, j] + y_serie + y_shunt_half

        return Ybus
    except Exception as e:
        print(f"Ocorreu um erro ao montar a matriz Ybus: {e}")
        exit()


def get_col_or_default(df, col_name, default_val):
    """Lê uma coluna do df. Se não existir, retorna um array de default_val."""
    import pandas as pd
    if col_name in df.columns:
        return df[col_name].to_numpy()
    else:
        # Retorna um array do tamanho certo com o valor default
        return np.full(len(df), default_val)


def fluxo_newton_raphson(df_fluxo, Ybus, iteracoes=3, tolerancia=1e-5):
    """
    Calcula o fluxo de potência pelo método de Newton-Raphson
    considerando um modelo de carga ZIP (Tensão-Dependente).

    Argumentos:
    df_fluxo: DataFrame com os dados das barras.
              Para o modelo ZIP, deve conter as colunas:
              'Kpp', 'Kpi', 'Kpz' (soma deve ser 1 ou 0)
              'Kqp', 'Kqi', 'Kqz' (soma deve ser 1 ou 0)
              Se as colunas não existirem, assume 100% potência constante.
    Ybus: Matriz de admitância do sistema (numpy array complexo).
    iteracoes: Número máximo de iterações.
    tolerancia: Critério de convergência para o mismatch máximo.

    Retorna:
    Um DataFrame com os resultados das variáveis (V, phi, P, Q).
    """
    import numpy as np
    import pandas as pd
    try:
        # --- 1. Inicialização ---
        n_barras = len(df_fluxo)

        # Separa G e B da Ybus
        G = np.real(Ybus)
        B = np.imag(Ybus)

        # Tipo de barra (array)
        tipo = df_fluxo['tipo_barra'].to_numpy()

        # Índices das barras
        pq_buses = np.where(tipo == 'PQ')[0]
        pv_buses = np.where(tipo == 'PV')[0]
        swing_bus = np.where(tipo == 'swing')[0][0]

        # Barras que entram no cálculo da Jacobiana (não-swing)
        non_swing_buses = np.where(tipo != 'swing')[0]

        # --- Dados do Modelo ZIP ---
        # Cargas totais especificadas (Pci, Qci)
        P_carga_base = df_fluxo['Pci'].to_numpy()
        Q_carga_base = df_fluxo['Qci'].to_numpy()

        # Geração especificada
        P_gen_spec = df_fluxo['Pgi'].to_numpy()
        Q_gen_spec = df_fluxo['Qgi'].to_numpy()

        # Checa se alguma coluna ZIP existe
        zip_cols_present = any(c in df_fluxo.columns for c in [
                               'Kpp', 'Kpi', 'Kpz', 'Kqp', 'Kqi', 'Kqz'])

        if zip_cols_present:
            print("  Modelo de carga ZIP detectado. Lendo coeficientes.")
            # Coeficientes de Potência Ativa
            Kpp = get_col_or_default(df_fluxo, 'Kpp', 0.0)
            Kpi = get_col_or_default(df_fluxo, 'Kpi', 0.0)
            Kpz = get_col_or_default(df_fluxo, 'Kpz', 0.0)
            # Coeficientes de Potência Reativa
            Kqp = get_col_or_default(df_fluxo, 'Kqp', 0.0)
            Kqi = get_col_or_default(df_fluxo, 'Kqi', 0.0)
            Kqz = get_col_or_default(df_fluxo, 'Kqz', 0.0)

            # Garante que, se a soma for 0, use 100% P-constante
            # (evita divisão por zero se o usuário não preencher nada)
            soma_p = Kpp + Kpi + Kpz
            soma_q = Kqp + Kqi + Kqz

            idx_p_zero = np.where(soma_p == 0)[0]
            Kpp[idx_p_zero] = 1.0

            idx_q_zero = np.where(soma_q == 0)[0]
            Kqp[idx_q_zero] = 1.0

        else:
            print(
                "  Modelo de carga ZIP não encontrado. Assumindo 100% Potência Constante.")
            Kpp = np.ones(n_barras)  # 100% Pot Constante
            Kpi = np.zeros(n_barras)
            Kpz = np.zeros(n_barras)
            Kqp = np.ones(n_barras)  # 100% Pot Constante
            Kqi = np.zeros(n_barras)
            Kqz = np.zeros(n_barras)

        # ---------------------------

        # Vetor de estado inicial (V e delta)
        V_mag = df_fluxo['Ei'].to_numpy().copy()
        # Assume que 'Fi' está em RADIANOS
        V_ang = df_fluxo['Fi'].to_numpy().copy()

        # Garante "flat start" (1.0 p.u., 0 rad) se não especificado
        V_mag[V_mag == 0.0] = 1.0
        V_ang[pq_buses] = 0.0
        V_ang[pv_buses] = 0.0

        # Arrays para armazenar resultados (iter + 1 para estado inicial)
        Vim = np.zeros((iteracoes + 1, n_barras), dtype=complex)
        Pim = np.zeros((iteracoes + 1, n_barras))
        Qim = np.zeros((iteracoes + 1, n_barras))

        Vim[0] = V_mag * np.exp(1j * V_ang)
        # (Pim[0] e Qim[0] serão calculados na iteração 0)

        # Mapeamento de índices para a Jacobiana
        delta_idx_map = {bus_idx: i for i,
                         bus_idx in enumerate(non_swing_buses)}
        v_idx_map = {bus_idx: i for i, bus_idx in enumerate(pq_buses)}

        n_ns = len(non_swing_buses)  # n_pv + n_pq
        n_pq = len(pq_buses)

        print(f"Iniciando Newton-Raphson (ZIP) para {n_barras} barras.")
        print(f"  Tamanho da Jacobiana: {(n_ns + n_pq)} x {(n_ns + n_pq)}")

        # --- 2. Loop de Iterações ---
        num_resultados = iteracoes + 1

        for i in range(iteracoes):

            V_complex = V_mag * np.exp(1j * V_ang)

            # --- 2a. Calcular Potências Injetadas (P_inj, Q_inj) ---
            # S_inj* = V* . (Ybus . V)
            S_star_inj = V_complex.conj() * (Ybus.dot(V_complex))
            P_inj = S_star_inj.real
            Q_inj = -S_star_inj.imag  # S* = P - jQ, então Q = -imag(S*)

            # --- 2b. Calcular Cargas (P_load, Q_load) - MODELO ZIP ---
            # V0 é assumido como 1.0 p.u.
            P_load = P_carga_base * (Kpp + Kpi * V_mag + Kpz * V_mag**2)
            Q_load = Q_carga_base * (Kqp + Kqi * V_mag + Kqz * V_mag**2)

            # --- 2c. Calcular Mismatches (Delta P, Delta Q) ---
            # Mismatch = Geração_Spec - Carga_Calc - Injeção_Calc
            delta_P = P_gen_spec - P_load - P_inj
            delta_Q = Q_gen_spec - Q_load - Q_inj

            # Vetor Mismatch (apenas barras relevantes)
            mismatch_P = delta_P[non_swing_buses]
            mismatch_Q = delta_Q[pq_buses]
            mismatch_vector = np.concatenate([mismatch_P, mismatch_Q])

            # --- 2d. Checar Convergência ---
            max_mismatch = np.max(np.abs(mismatch_vector))

            # Armazena os valores ANTES da correção
            # Geração = Injeção + Carga
            if i == 0:  # Armazena estado inicial
                Pim[0] = P_inj + P_load
                Qim[0] = Q_inj + Q_load

            if max_mismatch < tolerancia:
                print(
                    f"Newton-Raphson (ZIP) convergiu na iteração {i} (Mismatch: {max_mismatch:.2e})")
                num_resultados = i + 1
                break

            print(f"  Iteração {i+1}: Mismatch max = {max_mismatch:.4e}")

            # --- 2e. Calcular Derivadas da Carga (para a Jacobiana) ---
            # d(P_load) / d|V|
            dP_load_dV = P_carga_base * (Kpi + 2.0 * Kpz * V_mag)
            # d(Q_load) / d|V|
            dQ_load_dV = Q_carga_base * (Kqi + 2.0 * Kqz * V_mag)

            # --- 2f. Montar a Jacobiana ---
            # J = J_injeção + J_carga
            # J_carga só tem termos na diagonal de J12 e J22

            J11 = np.zeros((n_ns, n_ns))  # dP/d_delta
            J12 = np.zeros((n_ns, n_pq))  # dP/d_V
            J21 = np.zeros((n_pq, n_ns))  # dQ/d_delta
            J22 = np.zeros((n_pq, n_pq))  # dQ/d_V

            # Loop por todas as barras para preencher a Jacobiana
            for r in range(n_barras):  # Barra 'r' (linha)

                Vi = V_mag[r]

                # --- Termos Diagonais (r == c) ---

                # J_injeção (P_inj, Q_inj) - (Standard)
                J11_ii_inj = -Q_inj[r] - (B[r, r] * Vi**2)
                J21_ii_inj = P_inj[r] - (G[r, r] * Vi**2)
                J12_ii_inj = (P_inj[r] / Vi) + (G[r, r] * Vi)
                J22_ii_inj = (Q_inj[r] / Vi) - (B[r, r] * Vi)

                # J_carga (P_load, Q_load) - (Novo)
                # d(P_load_i) / d(delta_i) = 0
                # d(Q_load_i) / d(delta_i) = 0
                J12_ii_load = dP_load_dV[r]
                J22_ii_load = dQ_load_dV[r]

                # Termos FINAIS da Jacobiana (J_inj + J_load)
                J11_ii = J11_ii_inj  # + 0
                J21_ii = J21_ii_inj  # + 0
                J12_ii = J12_ii_inj + J12_ii_load
                J22_ii = J22_ii_inj + J22_ii_load

                # Atribui se a barra 'r' for relevante
                if r in delta_idx_map:  # Linha de P (PV ou PQ)
                    row_p = delta_idx_map[r]
                    col_d = delta_idx_map[r]
                    J11[row_p, col_d] = J11_ii
                    if r in v_idx_map:  # Coluna de V (só PQ)
                        col_v = v_idx_map[r]
                        J12[row_p, col_v] = J12_ii

                if r in v_idx_map:  # Linha de Q (só PQ)
                    row_q = v_idx_map[r]
                    col_d = delta_idx_map[r]  # Coluna de delta
                    J21[row_q, col_d] = J21_ii
                    col_v = v_idx_map[r]  # Coluna de V
                    J22[row_q, col_v] = J22_ii

                # --- Termos Fora-Diagonal (r != c) ---
                # (Não mudam, pois d(Load_i) / d(V_j) = 0)
                for c in range(n_barras):  # Barra 'c' (coluna)
                    if r == c:
                        continue

                    Vk = V_mag[c]
                    theta_ik = V_ang[r] - V_ang[c]
                    cos_th = np.cos(theta_ik)
                    sin_th = np.sin(theta_ik)

                    Gik = G[r, c]
                    Bik = B[r, c]

                    # Termos da injeção (J_std)
                    J11_ik = Vi * Vk * (Gik * sin_th - Bik * cos_th)
                    J12_ik = Vi * Vk * (Gik * cos_th + Bik * sin_th)
                    J21_ik = -Vi * Vk * (Gik * cos_th + Bik * sin_th)
                    J22_ik = Vi * Vk * (Gik * sin_th - Bik * cos_th)

                    # Atribui se a combinação r, c for relevante
                    if r in delta_idx_map and c in delta_idx_map:
                        J11[delta_idx_map[r], delta_idx_map[c]] = J11_ik
                    if r in delta_idx_map and c in v_idx_map:
                        J12[delta_idx_map[r], v_idx_map[c]] = J12_ik
                    if r in v_idx_map and c in delta_idx_map:
                        J21[v_idx_map[r], delta_idx_map[c]] = J21_ik
                    if r in v_idx_map and c in v_idx_map:
                        J22[v_idx_map[r], v_idx_map[c]] = J22_ik

            # --- 2g. Montar Jacobiana completa e Resolver ---
            J_top = np.hstack([J11, J12])
            J_bottom = np.hstack([J21, J22])
            J = np.vstack([J_top, J_bottom])

            try:
                # Resolve J * delta_x = mismatch_vector
                delta_x = np.linalg.solve(J, mismatch_vector)
            except np.linalg.LinAlgError:
                print(
                    f"Erro: Jacobiana singular na iteração {i+1}. Abortando.")
                num_resultados = i + 1
                break

            # --- 2h. Atualizar Vetor de Estado (V e delta) ---
            delta_delta = delta_x[:n_ns]
            delta_v_mag = delta_x[n_ns:]

            V_ang[non_swing_buses] += delta_delta
            V_mag[pq_buses] += delta_v_mag

            # Força magnitude de V em barras PV (especificação)
            V_mag[pv_buses] = df_fluxo['Ei'][pv_buses].to_numpy()

            # --- 2i. Armazenar Resultados da Iteração ---
            V_complex_final = V_mag * np.exp(1j * V_ang)
            Vim[i+1] = V_complex_final

            # Recalcula P/Q finais (incluindo Swing) com os novos V
            S_star_final_inj = (V_complex_final.conj()) * \
                (Ybus.dot(V_complex_final))
            P_inj_final = S_star_final_inj.real
            Q_inj_final = -S_star_final_inj.imag

            # Recalcular cargas finais
            P_load_final = P_carga_base * (Kpp + Kpi * V_mag + Kpz * V_mag**2)
            Q_load_final = Q_carga_base * (Kqp + Kqi * V_mag + Kqz * V_mag**2)

            # Geração Total = Injeção de Rede + Demanda de Carga
            P_gen_final = P_inj_final + P_load_final
            Q_gen_final = Q_inj_final + Q_load_final

            Pim[i+1] = P_gen_final
            Qim[i+1] = Q_gen_final

        # Fim do loop de iterações

        if i == iteracoes - 1 and max_mismatch > tolerancia:
            print(
                f"Atenção: Newton-Raphson (ZIP) NÃO convergiu em {iteracoes} iterações.")
            num_resultados = iteracoes + 1

        # --- 3. Formatação do DataFrame de Saída (igual ao G-S) ---

        # Trunca arrays de resultado se convergiu antes
        mag = np.abs(Vim[:num_resultados])
        phasor = np.degrees(np.angle(Vim[:num_resultados]))
        potReativa = Qim[:num_resultados]
        potAtiva = Pim[:num_resultados]

        z = num_resultados  # Número de linhas (it_0, it_1, ...)

        # (O restante do código para formatar o DataFrame de saída
        # é exatamente igual ao da sua função anterior)

        # 1. Nomes das colunas
        mag_cols = [f'E_bar{b+1}' for b in range(n_barras) if tipo[b] == 'PQ']
        phasor_cols = [
            f'phi_bar{b+1}' for b in range(n_barras) if tipo[b] != 'swing']
        potReativa_cols = [
            # PV e Swing
            f'Q_bar{b+1}' for b in range(n_barras) if tipo[b] != 'PQ']
        potAtiva_cols = [
            f'P_bar{b+1}' for b in range(n_barras) if tipo[b] == 'swing']

        # 2. Máscaras booleanas
        mask_mag = [tipo[b] == 'PQ' for b in range(n_barras)]
        mask_phasor = [tipo[b] != 'swing' for b in range(n_barras)]
        mask_potReativa = [tipo[b] != 'PQ' for b in range(n_barras)]
        mask_potAtiva = [tipo[b] == 'swing' for b in range(n_barras)]

        # 3. Filtra os DADOS
        mag_filtrado = mag[:, mask_mag]
        phasor_filtrado = phasor[:, mask_phasor]
        potReativa_filtrada = potReativa[:, mask_potReativa]
        potAtiva_filtrada = potAtiva[:, mask_potAtiva]

        # 4. Junta nomes e dados
        cols = mag_cols + phasor_cols + potReativa_cols + potAtiva_cols
        # Tratamento para caso de não haver colunas (evita erro no hstack)
        dados_list = []
        if mag_filtrado.size > 0:
            dados_list.append(mag_filtrado)
        if phasor_filtrado.size > 0:
            dados_list.append(phasor_filtrado)
        if potReativa_filtrada.size > 0:
            dados_list.append(potReativa_filtrada)
        if potAtiva_filtrada.size > 0:
            dados_list.append(potAtiva_filtrada)

        if not dados_list:
            print("Nenhum dado de resultado para exibir (verifique os tipos de barra).")
            return pd.DataFrame()

        dados_filtrados = np.hstack(dados_list)

        # 5. Cria o DataFrame
        df_vim = pd.DataFrame(dados_filtrados, columns=cols, index=[
                              f'it_{i}' for i in range(z)])

        # Adiciona colunas de diferença (exatamente como no seu código)
        df = df_vim.copy()
        nova_ordem = []

        for col in df.columns:
            diff = df[col] - df[col].shift(1)
            diff.iloc[0] = 0  # primeira linha = 0
            diff_col = f"{col}_diff"
            df[diff_col] = diff
            nova_ordem.append(col)
            nova_ordem.append(diff_col)

        df_vim = df[nova_ordem]

        return df_vim

    except Exception as e:
        print(
            f"Ocorreu um erro durante o cálculo do fluxo (Newton-Raphson ZIP): {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()  # Retorna DF vazio em caso de erro
